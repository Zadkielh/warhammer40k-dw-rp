ITEM.name = "Peacekeeper Mk2"
ITEM.desc = [[The Peacekeeper Mk2 is the successor to the Peacekeeper. THe most notable change being that the Peacekeeper Mk2 is an Assault Rifle, while the original was a Submachine Gun. It has a larger magazine, slower rate of fire, which it makes up for in damage and range.]]
			
ITEM.model = "models/weapons/v_bo3_peacekeeper.mdl"
ITEM.class = "bo3_peacekeeper"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.price = 0
ITEM.height = 2
ITEM.flag = "v"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}