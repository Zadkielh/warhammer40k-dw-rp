ITEM.name = ".700 Nitro"
ITEM.desc = [[The .700 Nitro is a double barreled shotgun that fires a big slug round.]]
			
ITEM.model = "models/weapons/v_fc4_700nitro.mdl"
ITEM.class = "fc4_700nitro"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.price = 0
ITEM.height = 2
ITEM.flag = "v"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}