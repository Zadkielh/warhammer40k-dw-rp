ITEM.name = "Remington 870"
ITEM.desc = [[The Remington Model 870 is a pump-action shotgun. It is widely used by the public for sport shooting and self defense. It is also used by law enforcement.]]
			
ITEM.model = "models/weapons/w_smg_mpd.mdl"
ITEM.class = "weapon_hf_870"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.price = 0
ITEM.height = 2
ITEM.flag = "v"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}