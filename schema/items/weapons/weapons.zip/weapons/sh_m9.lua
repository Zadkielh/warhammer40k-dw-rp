ITEM.name = "M9"
ITEM.desc = [[The M9 (Beretta M9) is a Semi Automatic Pistol, chambered in 9x19mm Parabellum rounds.]]
			
ITEM.model = "models/weapons/w_pist_neagle.mdl"
ITEM.class = "weapon_hf_m9"
ITEM.weaponCategory = "primary"
ITEM.width = 2
ITEM.price = 0
ITEM.height = 2
ITEM.flag = "v"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}