ITEM.name = "M110"
ITEM.desc = [[The M110 is a Semi Automatic DMR/Sniper Rifle, chambered in 7.62x51mm NATO rounds.]]
			
ITEM.model = "models/weapons/w_snip_sh550.mdl"
ITEM.class = "weapon_hf_m110_rt"
ITEM.weaponCategory = "primary"
ITEM.width = 5
ITEM.price = 0
ITEM.height = 2
ITEM.flag = "v"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}