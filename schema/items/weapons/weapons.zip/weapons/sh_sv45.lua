ITEM.name = "SV-45"
ITEM.desc = [[The SV45 is a submachine gun that uses an unconventional delayed blowback system combined with in-line design to reduce percieved recoil and muzzle climb.
			It has a scope attatched]]
			
ITEM.model = "models/weapons/w_smg_ums45.mdl"
ITEM.class = "weapon_hf_sv45"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.price = 0
ITEM.height = 2
ITEM.flag = "v"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}