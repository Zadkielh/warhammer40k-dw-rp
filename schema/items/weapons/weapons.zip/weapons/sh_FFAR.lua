ITEM.name = "FFAR"
ITEM.desc = [[The FFAR (Sometimes referred to as FAMAS) is a bullpup assault rifle, It has a high fire rate.]]
			
ITEM.model = "models/weapons/v_bo3_ffar.mdl"
ITEM.class = "bo3_ffar"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.price = 0
ITEM.height = 2
ITEM.flag = "v"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}